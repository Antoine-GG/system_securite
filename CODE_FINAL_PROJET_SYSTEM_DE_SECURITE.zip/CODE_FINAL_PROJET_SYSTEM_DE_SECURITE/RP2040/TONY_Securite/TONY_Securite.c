#include <stdio.h>
#include <string.h>

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/sync.h"
#include "hardware/structs/ioqspi.h"
#include "hardware/structs/sio.h"
#include "pico/binary_info.h"
#include "hardware/spi.h"

#define BUF_LEN 0x08

#define MISO 16
#define CS   17
#define SCLK 18
#define MOSI 19


uint32_t previousMillis = 0;
uint32_t previousMillis2 = 0;
const uint32_t interval = 10;
const uint32_t interval2 = 10;

void printbuf(uint8_t buf[], size_t len) {
    int i;
    for (i = 0; i < len; ++i) {
        if (i % 16 == 15)
            printf("%02x\n", buf[i]);
        else
            printf("%02x ", buf[i]);
    }

    // append trailing newline if there isn't one
    if (i % 16) {
        putchar('\n');
    }
}

char keypad_read_all_keys(){
    char KeyPad_Pin_Num[12] = "*7410852#963";
    char CHAR_TO_RETURN[1];
    
    //printf("Timestamp: %lu\n", timestamp_from_core);
    for (uint8_t i = 2; i < 15; i++){
        
        //printf("reading pins\n");
        if(gpio_get(i) == true){
            //printf("GPIO_%lu: %d\n", i, gpio_get(i));
            CHAR_TO_RETURN[0] = KeyPad_Pin_Num[(i - 2)];
            return CHAR_TO_RETURN[0];
        }
        if(i == 13){
                return 'F';
        }
    }
}

int main() {
    set_sys_clock_khz(100000, true);
    stdio_init_all();
    bool cycle_flag = 0;
    bool SPI_CS_ACTIVATED = 0;
    char READING_Keys[1];
    bool flag_unclick = 0;
    char Keypad_Password[5] = {'F','F','F','F'};
    char good_password[4] = {'0','2','0','5'};
    uint16_t Password_size = 0;
    bool Password_entered = 0;
    uint8_t Last_entred_Password = 0;
    // Enable SPI 0 at 1 MHz and connect to GPIOs
    gpio_init(15);
    gpio_set_dir(15, GPIO_OUT);
    spi_init(spi_default, 1000 * 1000);
    spi_set_slave(spi_default, true);
    gpio_set_function(MISO, GPIO_FUNC_SPI);
    gpio_set_function(SCLK, GPIO_FUNC_SPI);
    gpio_set_function(MOSI, GPIO_FUNC_SPI);
    gpio_set_function(CS, GPIO_FUNC_SPI);
    // Make the SPI pins available to picotool
    bi_decl(bi_4pins_with_func(MISO, MOSI, SCLK, CS, GPIO_FUNC_SPI));

    uint8_t in_buf[BUF_LEN];
    uint8_t data2[] = {0x42};
    uint8_t asking_if_password[1] = {0x07};
    uint8_t bad_Password[1] = {0x05};
    uint8_t good_Password[1] = {0x06};

    int i;
    size_t in_buff_length;

    while (1) {
        uint32_t timestamp = time_us_32();
        uint32_t currentMillis = time_us_32() / 1000;
        if (currentMillis - previousMillis >= interval) {
            previousMillis = currentMillis;
            //char keypress[1] = {keypad_read_all_keys()};

            READING_Keys[0] = keypad_read_all_keys();
            if (READING_Keys[0] == 'F'){
                flag_unclick = 1;
            }
            READING_Keys[0] = keypad_read_all_keys();
            if (READING_Keys[0] != 'F' && flag_unclick == 1){
                //printf("%c\n", READING_Keys[0]);
                Keypad_Password[Password_size] = READING_Keys[0];
                Password_size = Password_size + 1;
                for(uint16_t i = 0; i < Password_size; i++){
                    printf("%c", Keypad_Password[i]);  
                }
                printf("\n");
                flag_unclick = 0;
                if (Keypad_Password[0] != 'F' && Keypad_Password[1] != 'F' && Keypad_Password[2] != 'F' && Keypad_Password[3] != 'F'){
                    Password_entered = 1; 

                    if (Keypad_Password[0] == good_password[0] && Keypad_Password[1] == good_password[1] && Keypad_Password[2] == good_password[2] && Keypad_Password[3] == good_password[3]){
                    printf("good Password\n");
                    Password_size = 0;
                    Keypad_Password[0] = 'F';
                    Keypad_Password[1] = 'F';
                    Keypad_Password[2] = 'F';
                    Keypad_Password[3] = 'F';
                    Last_entred_Password = 1;
                    
                    }
                else{
                    printf("Bad Password\n");
                    Password_size = 0;
                    Keypad_Password[0] = 'F';
                    Keypad_Password[1] = 'F';
                    Keypad_Password[2] = 'F';
                    Keypad_Password[3] = 'F';
                    Last_entred_Password = 2;
                    }
            }
        
            }
            cycle_flag = 1;
        }

        
        if (Password_entered == 0) {
            gpio_put(15, 1);
            if (gpio_get(17) == false) {
            spi_write_read_blocking(spi_default, data2, in_buf, 1); 
            //printbuf(in_buf, 1);
            gpio_put(15, 0);
            }
        }      

        if (Password_entered == 1 && Last_entred_Password == 1){
            printf("Sending the good password to the SPI master\n");
            spi_write_read_blocking(spi_default, good_Password, in_buf, 1);
            Password_entered = 0;
        }
        if (Password_entered == 1 && Last_entred_Password == 2){
            Password_entered = 0;
            printf("Sending the bad password to the SPI master\n");
            spi_write_read_blocking(spi_default, bad_Password, in_buf, 1);
            Password_entered = 0;
            
        }
        }
    
    return 0;
}
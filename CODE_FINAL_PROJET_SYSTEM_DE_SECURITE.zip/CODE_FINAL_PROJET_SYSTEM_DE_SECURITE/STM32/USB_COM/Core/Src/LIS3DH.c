/*
 * LIS3DH.c
 *
 *  Created on: Dec 18, 2023
 *      Author: tonyg
 */


void LIS3DH_init(){

}

